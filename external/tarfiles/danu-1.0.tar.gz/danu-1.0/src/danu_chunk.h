/* *************************************************************************** *
*                                                                              *
*                                                                              *
*                             Copyright  (C) 20xx,                             *
*                      Los Alamos National Security, LLC                       *
*                                                                              *
*                             LA-CC-xxxxxx                                     *
*                                                                              *
* **************************************************************************** */

/*
* danu_chunk.h
*
*  DANU Dataset chunking module
*
*/

#ifndef DANU_CHUNK_H
#define DANU_CHUNK_H

#include <danu_types.h>

//dchunk_params_t * danu_chunk_params_alloc(int ndim );
//void              danu_chunk_params_free(dchunk_params_t * ptr);

#endif

