/* *************************************************************************** *
*                                                                              *
*                                                                              *
*                             Copyright  (C) 20xx,                             *
*                      Los Alamos National Security, LLC                       *
*                                                                              *
*                             LA-CC-xxxxxx                                     *
*                                                                              *
* **************************************************************************** */

/*
* danu_fort_output.h
*
*  DANU FORTRAN/C TOUT Output file interfaces
*
*/

#ifndef TOUT_FORT_OUTPUT_H
#define TOUT_FORT_OUTPUT_H

/* Function prototypes corresponding interface definition in module_danu_iface.f90 */




#endif /* TOUT_FORT_OUTPUT_H */

