/* *************************************************************************** *
*                                                                              *
*                                                                              *
*                             Copyright  (C) 20xx,                             *
*                      Los Alamos National Security, LLC                       *
*                                                                              *
*                             LA-CC-xxxxxx                                     *
*                                                                              *
* **************************************************************************** */

/*
 * Danu Mesh Objects Interface (SWIG-WRAP)
 *
 * C Interface Ouput Objects
 *
 */
#ifndef DANU_PY_MESH_IFACE_H
#define DANU_PY_MESH_IFACE_H

#include
herr_t
#endif


