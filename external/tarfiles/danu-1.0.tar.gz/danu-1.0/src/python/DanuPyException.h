#ifndef DANU_PY_EXCEPT_H
#define DANU_PY_EXCEPT_H

void   throw_exception(char *msg);
void   clear_exception();
char * check_exception(void);

#endif
