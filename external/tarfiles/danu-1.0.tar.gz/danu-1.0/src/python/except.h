#ifndef _EXCEPT_H_
#define _EXCEPT_H_

void throw_exception(const char *msg);
void clear_exception(void);
char * check_exception(void);

#endif
